package com.cg.mra.service;

import com.cg.mra.beans.Account;

import com.cg.mra.exception.PhoneNumberDoesNotExistException;


public interface IAccountService {
	 Account getAccountDetails(String mobileNo) throws  PhoneNumberDoesNotExistException;
	 double rechargeAccount(String mobileNo,double rechargeAmount) throws  PhoneNumberDoesNotExistException;

}
