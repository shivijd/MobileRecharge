package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.IAccountDao;

import com.cg.mra.exception.PhoneNumberDoesNotExistException;



public class AccountServiceImplementation implements IAccountService {

	IAccountDao iaccdao;        //Reference of Dao Class to call Dao Methods
	
	public AccountServiceImplementation(IAccountDao iaccdao) {
		super();
		this.iaccdao=iaccdao;
	}

	@Override
	public Account getAccountDetails(String mobileNo) throws  PhoneNumberDoesNotExistException {		
	   Account account= iaccdao.getAccountDetails(mobileNo);	
	   return account;
	}

	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) throws  PhoneNumberDoesNotExistException {	
		return iaccdao.rechargeAccount(mobileNo, rechargeAmount);
	
	}

}
