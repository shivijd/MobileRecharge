package com.cg.mra.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.cg.mra.dao.AccountDaoImplementation;
import com.cg.mra.dao.IAccountDao;

import com.cg.mra.exception.PhoneNumberDoesNotExistException;
import com.cg.mra.service.AccountServiceImplementation;
import com.cg.mra.service.IAccountService;

public class MobileRechargeTest {

	private static IAccountDao idao = new AccountDaoImplementation();
	private static IAccountService iservice = new AccountServiceImplementation(idao);
	
	/*
	 * RECHARGE ACCOUNT
	 * 
	 * 1. When corrrect details is passed it should recharge amount
	 * 2. When invalid mobil;e number is passed it should throw exceo
	 */
	
	@Test
	public void WhenCorrectDetailsIsPassedItShouldRechargeAccount() throws PhoneNumberDoesNotExistException
	{
		iservice.rechargeAccount("7500725707", 500);
	}
	
	@Test(expected=PhoneNumberDoesNotExistException.class)
	public void WhenPhoneNumberDoesNotExist() throws  PhoneNumberDoesNotExistException
	{
		iservice.rechargeAccount("8500725707", 500);
	}
	
	
	/*
	 * Show Details
	 * 
	 * 1. When corrrect details is passed it should recharge amount
	 * 2. When invalid mobil;e number is passed it should throw exceo
	 */
	
	@Test
	public void WhenCorrectDetailsIsPassedItShouldShowDetails() throws PhoneNumberDoesNotExistException
	{
		iservice.rechargeAccount("7500725707", 500);
	}
	
	@Test(expected=PhoneNumberDoesNotExistException.class)
	public void WhenPhoneNumberDoesNotExistItShouldThrowException() throws PhoneNumberDoesNotExistException
	{
		iservice.rechargeAccount("8500725707", 500);
	}

}
