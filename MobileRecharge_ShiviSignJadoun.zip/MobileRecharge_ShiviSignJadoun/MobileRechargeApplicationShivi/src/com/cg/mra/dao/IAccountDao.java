package com.cg.mra.dao;

import com.cg.mra.beans.Account;

import com.cg.mra.exception.PhoneNumberDoesNotExistException;

public interface IAccountDao {
	
	Account getAccountDetails(String mobileNo) throws PhoneNumberDoesNotExistException;                        
	double rechargeAccount(String mobileNo,double rechargeAmount) throws  PhoneNumberDoesNotExistException;

}
