package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import com.cg.mra.beans.Account;


import com.cg.mra.exception.PhoneNumberDoesNotExistException;

public class AccountDaoImplementation implements IAccountDao{
	HashMap <String, Account>accountEntry;	
	public AccountDaoImplementation()
	{
		accountEntry=new HashMap<>();  //There is some duplicate values of mobileNumber so we have changed them
		accountEntry.put("7500725707", new Account("7500725707","Prepaid", "Vaishali", 200));
		accountEntry.put("9823920123", new Account("9823920123","Prepaid", "Megha", 453));
		accountEntry.put("9932012345", new Account("9932012345","Prepaid", "Vikas", 631));
		accountEntry.put("9010210131", new Account("9010210131","Prepaid", "Anju", 521));
		accountEntry.put("9956321397", new Account("9956321397","Prepaid", "Tushar", 632));
	}

	@Override
	public Account getAccountDetails(String mobileNo) throws  PhoneNumberDoesNotExistException {
		Account ctemp=null;
		Iterator<Entry<String, Account>> dataTrav=accountEntry.entrySet().iterator();
		while(dataTrav.hasNext())
		{
			Map.Entry<String, Account> data=(Map.Entry<String, Account>)dataTrav.next();
			if(data.getKey().equals(mobileNo))
			{
				ctemp=data.getValue();
				return data.getValue();
			}
		}			
		
		if(ctemp!=null)
			return ctemp;
		else
			throw new com.cg.mra.exception.PhoneNumberDoesNotExistException();
		
			}


	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) throws PhoneNumberDoesNotExistException{
		Account account=accountEntry.get(mobileNo);
		if(account==null) {
			throw new PhoneNumberDoesNotExistException();
		}
		 account.setAccountBalance(account.getAccountBalance()+rechargeAmount);
     return  account.getAccountBalance();
	}

	}

