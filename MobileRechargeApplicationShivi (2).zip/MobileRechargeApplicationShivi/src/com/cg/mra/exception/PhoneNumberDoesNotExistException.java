package com.cg.mra.exception;

public class PhoneNumberDoesNotExistException extends Exception {

}
