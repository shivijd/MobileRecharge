package com.cg.mra.ui;

import java.util.Scanner;
import java.util.regex.Pattern;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDaoImplementation;
import com.cg.mra.dao.IAccountDao;

import com.cg.mra.exception.PhoneNumberDoesNotExistException;
import com.cg.mra.service.AccountServiceImplementation;
import com.cg.mra.service.IAccountService;


public class MainUI {
	private static Scanner scanner = new Scanner(System.in);
	private static IAccountDao idao = new AccountDaoImplementation();
	private static IAccountService iservice = new AccountServiceImplementation(idao);
 
	public static void main(String[] args) throws PhoneNumberDoesNotExistException{
	
		//******************************************************//
		int choice;
		
		while(true)
		{
			System.out.println("enter choice");
			System.out.println("1: Recharge account");
			System.out.println("2: show details");
			System.out.println("3 Exit");
			choice=scanner.nextInt();
			
			switch(choice)
			{
			case 1: rechargeAccount();
				break;
			case 2: showDetails();
				break;
			case 3: System.exit(0);
				break;
			default: System.out.println("wrong");
			
			}
		}
		
		

}

	private static void showDetails() throws  PhoneNumberDoesNotExistException {
		// TODO Auto-generated method stub
		
		//Input for Phone Number
		System.out.println("Enter the phone number");
		String phoneNumber=scanner.next();
		while(!Pattern.matches("[789]{1}[0-9]{9}",phoneNumber))
		{
			System.out.println("Enter phone number again");
			phoneNumber=scanner.next();
		}
		
		
		
		Account account=iservice.getAccountDetails(phoneNumber);
		
		System.out.println(account);
		
		
		
	}

	private static void rechargeAccount() throws  PhoneNumberDoesNotExistException {
		// TODO Auto-generated method stub
		
		
		//Input for Phone Number
				System.out.println("Enter the phone number");
				String phoneNumber=scanner.next();
				while(!Pattern.matches("[789]{1}[0-9]{9}",phoneNumber))
				{
					System.out.println("Enter phone number again");
					phoneNumber=scanner.next();
				}
				
				
		//INput for amount
				System.out.println("Enter the amount");
				
				int amount=scanner.nextInt();
		
				double balance=iservice.rechargeAccount(phoneNumber, amount);
				
				System.out.println("Youtr acount recharged successfully");
				System.out.println("Hello "+ iservice.getAccountDetails(phoneNumber).getCustomerName()+", Available Balance is "+ iservice.getAccountDetails(phoneNumber).getAccountBalance());
				
				
	}
}
